
#!/bin/bash
cd /config
git add .
git commit -m "Sterling auto-update"
git push origin main
